# ENEM do Milhão · 2025 e 2026

Jogo de perguntas no estilo Show do Milhão com as questões do ENEM 2025 e 2026. Cada rodada sorteia 15 questões entre as provas e disciplinas marcadas na abertura.

## Como jogar

Abra `index.html` no navegador ou acesse a página publicada pelo GitHub Pages.

## Arquivos

- `index.html`: o jogo.
- `questoes.js`: lista das 366 questões, com prova, área e gabarito.
- `q/`: imagens das questões e dos textos de apoio, uma pasta por prova e dia.

## Fontes

- Questões: provas do ENEM 2025 e 2026, Inep.
- Gabarito de 2025: oficial do Inep.
- Gabarito de 2026: extraoficial, publicado pelo G1. A questão 153 do 2º dia ficou fora por não ter resposta nessa correção.
